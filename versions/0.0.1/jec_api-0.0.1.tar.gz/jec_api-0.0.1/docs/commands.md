# Commands

## Useful Commands

1. `pip install -e ".[dev]"`
2. `python -m build`
3. `twine upload dist/*`
4. `python -m jec_api --version`