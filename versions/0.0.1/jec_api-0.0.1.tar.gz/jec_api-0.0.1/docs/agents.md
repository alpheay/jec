# Agents

## Prompts

1. Create a changelog folder with a file called 0.0.1-0.0.2.md and document changes in there. Be very indepth in the change log but the readme can be a basic update. This read me is for 0.0.1 